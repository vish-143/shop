//Header file used in project
#include <iostream>
#include <conio.h>
#include <stdio.h>
#include <string.h>
#include <process.h>
#include <fstream>
using namespace std;
//class used in this project
class stock {
	int ino;
	char name[50];
	float price, qty, tax, dis;
public:
	//add function
	void add() {
		cout << "\nPlease Enter the Product no of Item:";
		cin >> ino;
		cout << "\n\nPlease Enter the Name of the Item:";
		cin >> gets(name);
		cout << "\nPlease Enter the Price of the Product:";
		cin >> price;
		cout << "\nPlease Enter the Discount(in %):";
		cin >> dis;
	}
	//display function
	void display() {
		cout << "\nProduct No of the Item :" << ino;
		cout << "\nName of the Item :";
		puts(name);
		cout << "\nPrice of the Product :" << price;
		cout << "\nDiscount :" << dis;
	}
	int retino() {
		return ino;
	}
	float retprice() {
		return price;
	}
	char* retname() {
		return name;
	}
	int retdis() {
		return dis;
	}
};//class ends here

//global declaration for stream object,object
//file handling in project
fstream fp;
stock pr;
//function to write in file
void write_stock() {
	fp.open("Shop.dat", ios::out | ios::app);
	pr.add();
	fp.write((char*)&pr, sizeof(stock));
	fp.close();
	cout << "\n\nThe Product has been Created";
	getch();
}
//function to read all records from file
void display_all() {
	cout << "\n\n\n\t\tDisplay all Records!!!\n\n";
	fp.open("Shop.dat", ios::in);
	while (fp.read((char*)&pr, sizeof(stock))) {
		pr.display();
		cout << "\n\n___________________________________\n";
		getch();
	}
	fp.close();
	getch();
}
//function to modify record of file
void modify_product() {
	int no, found = 0;
	cout << "\n\n\n\tTo Modify";
	cout << "\n\n\tPlease Enter the Product No of the Item :";
	cin >> no;
	fp.open("Shop.dat", ios::in | ios::out);
	while (fp.read((char*)&pr, sizeof(stock)) && found == 0) {
		if (pr.retino() == no)
		{
			pr.display();
			cout << "\nPlease Enter the New Details of Item :" << endl;
			pr.add();
			int pos = -1 * sizeof(pr);
			fp.seekp(pos, ios::cur);
			fp.write((char*)&pr, sizeof(stock));
			cout << "\n\n\t Record Updated";
			found = 1;
		}
	}
	fp.close();
	if (found == 0)
		cout << "\n\n Record not Found";
	getch();
}
//function to delete record from file
void delete_product() {
	int no;
	cout << "\n\n\n\tDelete Record";
	cout << "\n\nPlease Enter the Product no of the Item you want to Delete :";
	cin >> no;
	fp.open("Shop.dat", ios::in | ios::out);
	fstream fp2;
	fp2.open("Temp.dat", ios::out);
	fp.seekg(0, ios::beg);
	while (fp.read((char*)&pr, sizeof(stock))) {
		if (pr.retino() != no) {
			fp2.write((char*)&pr, sizeof(stock));
		}
	}
	fp2.close();
	fp.close();
	remove("Shop.dat");
	rename("Temp.dat", "Shop.dat");
	cout << "\n\n\tRecord Deleted...";
	getch();
}
//function to display all product price list
void menu() {
	fp.open("Shop.dat", ios::in);
	if (!fp) {
		cout << "ERROR!!! File could not be Open\n\n\n Go to Owner Menu to create file ";
		cout << "\n\n\nProgram is Closing....";
		getch();
	}
	cout << "\n\n\n\t\tItem Menu\n\n";
	cout << "_________________________________________________\n";
	cout << "I.NO.\t\tNAME\t\tPRICE\n";
	cout << "_________________________________________________\n";
	while (fp.read((char*)&pr, sizeof(stock))) {
		cout << pr.retino() << "\t\t" << pr.retname() << "\t\t" << pr.retprice() << endl;
	}
	fp.close();
}
//function to place order and generating bill for Products
void place_order() {
	int order_arr[50], quan[50], c = 0;
	float amt, damt, total = 0;
	char ch = 'Y';
	char name[50];
	menu();
	cout << "\n________________________________________________\n";
	cout << "\n Place Your Order";
	cout << "\n________________________________________________\n";
	do {
		cout << "\n\nEnter the Item No of the Product :";
		cin >> order_arr[c];
		cout << "\nQuantity in Number :";
		cin >> quan[c];
		c++;
		cout << "\nEnter your Name:";
		cin >> gets(name);
		cout << "\nDo you want to Order Another Product?(Y/N)";
		cin >> ch;
	} while (ch == 'y' || ch == 'Y');
	cout << "\n\nThank You for Placing the Order";
	getch();
	cout << "\n\n\t*************************** INVOICE **********************************\n";
	cout << "\nName\tI.No.\tItem Name\tQuantity \tPrice \tAmount \tAmount after Discount\n";
	for (int x = 0; x <= c; x++) {
		fp.open("Shop.dat", ios::in);
		fp.read((char*)&pr, sizeof(stock));
		while (!fp.eof()) {
			if (pr.retino() == order_arr[x]) {
				amt = pr.retprice() * quan[x];
				damt = amt - (amt * pr.retdis() / 100);
				cout << "\n" << name << "\t" << order_arr[x] << "\t" << pr.retname() <<
					"\t\t" << quan[x] << "\t\t" << pr.retprice() << "\t" << amt << "\t" << damt;
				total += damt;
			}
			fp.read((char*)&pr, sizeof(stock));
		}
		fp.close();
	}
	cout << "\n\n\t\t\t\t\tTOTAL =" << total;
	getch();
}
//Owner Menu Function
void owner_menu() {
	int ch;
start:
	string pass;
	char ch2;
	cout << "\n\nEnter your Password :";
	ch = getch();
	while (ch != 13) {
		pass.push_back(ch);
		cout << '*';
		ch = getch();
	}
	if (pass == "1234") {
		cout << "\n\n\n\tOwner Menu";
		cout << "\n\n\t1.Add Product";
		cout << "\n\n\t2.Display Items";
		cout << "\n\n\t3.Modify Item";
		cout << "\n\n\t4.Delete Item";
		cout << "\n\n\t5.View Product Menu";
		cout << "\n\n\t6.Back to Main Menu";
		cout << "\n\n\tPlease Enter your Choice:";
		ch2 = getche();
		switch (ch2) {
		case '1':
			write_stock();
			break;
		case '2':
			display_all();
			break;
		case '3':
			modify_product();
			break;
		case '4':
			delete_product();
			break;
		case '5':
			menu();
			getch();
		case '6':
			break;
		default:
			cout << "\a";
			owner_menu();
		}
	}
	else {
		cout << "\n\n Wrong Password,Try Again!!";
		goto start;
	}
}
//Staff menu Function
void staff_menu() {
	int ch;
start:
	string pass;
	char ch3;
	cout << "\n\nEnter your Password :";
	ch = getch();
	while (ch != 13) {
		pass.push_back(ch);
		cout << '*';
		ch = getch();
	}
	if (pass == "abcde") {
		cout << "\n\n\n\tStaff Menu";
		cout << "\n\n\t1.Display Items";
		cout << "\n\n\t2.Modify Item";
		cout << "\n\n\t3.View Product Menu";
		cout << "\n\n\t4.Back to Main Menu";
		cout << "\n\n\tPlease Enter your Choice:";
		ch3 = getche();
		switch (ch3) {
		case '1':
			display_all();
			break;
		case '2':
			modify_product();
			break;
		case '3':
			menu();
			getch();
		case '4':
			break;
		default:
			cout << "\b";
			staff_menu();
		}
	}
	else {
		cout << "\n\n Wrong Password,Try Again!!";
		goto start;
	}

}
//main function
int main()
{
	char ch;
	do {
		cout << "\n\n\n\t********************** Welcome to Shopping *****************************";
		cout << "\n\n\t1.Customer";
		cout << "\n\n\t2.Owner";
		cout << "\n\n\t3.Staff";
		cout << "\n\n\t4.Exit";
		cout << "\n\nPlease Enter your Response:";
		ch = getche();
		switch (ch) {
		case '1':
			place_order();
			getch();
			break;
		case '2':
			owner_menu();
			break;
		case '3':
			staff_menu();
			break;
		case '4':
			return 0;
		default:
			cout << "\a";
		}
	} while (ch != '4');
}